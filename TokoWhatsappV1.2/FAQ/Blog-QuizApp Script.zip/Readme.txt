Cara Install Blog QuizApp Script  ikuti langkah-langkahnya sebagai berikut :

============Install Step By Step============


1. Masuk Ke akun blogger kamu, pilih tema dan ubah tema menjadi tema klasik emporio.

2. Backup terlebih dahulu tema lama

3. Pilih file upload nasional-quiz.xml yang ada didalam folder asset-xml

4. Langkah Terakhir untuk persiapan install, upload semua gambar dan icon yang ada didalam folder blogspot-theme ini ke blog kalian. Kamu akan mendapat url gambar yang nntinya akan berguna untuk set up index pages.


Catatan :

Apabila tampilan kurang rapih silahkan buka pengaturan tema blog edit tema. 


1. Hapus semua kode yang ada, sekarang buka kode sumber nasional-quiz.xml copy dan paste di dalam editor tema blog yg barusan dihapus.

2. Klik save atau simpan.


================End Step===============

Cara Install Halaman Quiz Apps Script ikuti langkahnya sebagai berikut agar tdk ada kesalahan dalam membuat sampelnya :


Langkah Wajib :

A. Buat Halaman Index dengan nama Index Pages. Buka File kode sumber index.html di folder blog-pages copas di dalam editor html blog kamu.


B. Buat 1 halaman untuk menghubungkan Halaman index dan Halaman Quiz. Berikut langkah-langkahnya :



1. Untuk sampel buat 1 halaman blog kalian dengan nama inggrisA.


2. Buka Folder Blog-Pages. Pilih dan Buka File kode sumber file inggrisA.html. Copy kode sumber dari file tersebut.


3. Pastekan kode sumber tersebut dan klik simpan.


4. Ubah Nama Halaman inggrisA sesuai kehendak kamu.


Catatan :

1. Membuat nama halaman inggrisA berguna untuk menghubungkan antara Index Page dan Quiz Pages.


2. Semua langkah diatas pastikan anda melakukan hal tersebut didalam mode html editor bukan pada mode compose.


3. Untuk merubah konten silahkan ubah konten yang ada sesuai apa yang dikehendaki. Ingatt ! Ubah nya di dalam mode html.

4. Untuk install di hosting berbayar silahkan upload folder Install-hosting dapat melalui FTP atau Langsung lewat Cpanel kamu.

Jika ada kesulitan. Ajukan pertanyaan anda ke alamhafidz65@gmail.com atau website https://e-compfast.blogspot.com/p/contact.html
